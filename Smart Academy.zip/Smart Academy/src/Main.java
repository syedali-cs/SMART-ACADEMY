import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.swing.text.NavigationFilter;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.sun.javafx.scene.traversal.WeightedClosestCorner;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.application.ConditionalFeature;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.css.Styleable;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.effect.Effect;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
//import jfxtras.scene.control.CalendarPicker;



public class Main extends Application {

	public static void main(String[] args) {
		
launch(args);
	}

	String name="";
Scene scene1;
Scene smschedule;
AnchorPane ap=new AnchorPane();
Pane pane=new Pane();
Stage window=new Stage();

/// Registration Label

Button btn1=new Button("Sign Up");
Label l1=new Label("Don't Have An Account?");
Label l2=new Label("SMART ACADEMY: Learners Today, Leaders Tomorrow!");

//// Sign in Label

Button btn2=new Button("Sign In");
Label l3=new Label("Already have An Account?");
Label l4=new Label("SMART ACADEMY: Learners Today, Leaders Tomorrow!");

// Existing user
TextField etf=new TextField();
PasswordField pf=new PasswordField();
Button signin=new Button("Sign In");
Label error=new Label();
MenuItem Logout=new MenuItem("Log Out");
// New User
TextField nametf=new TextField();
TextField emailtf=new TextField();
PasswordField rpf=new PasswordField();
ObservableList<String> list=FXCollections.observableArrayList("Computer Science");
ComboBox<String> Department=new ComboBox<String>(list);
ObservableList<String> Type=FXCollections.observableArrayList("Student");
ComboBox<String> type=new ComboBox<String>(Type);
TextField pn=new TextField();
DatePicker birth=new DatePicker();
Button signup=new Button("Sign Up");
ToggleGroup tg=new ToggleGroup();
RadioButton male=new RadioButton("Male");
RadioButton female=new RadioButton("Female");

Label pusername=new Label(),pemail=new Label(),pphone=new Label(),pgender=new Label(),pdob=new Label(),pdept=new Label(),pCampus=new Label();

///
// Home Screen

BorderPane bp=new BorderPane();


Stage Home=new Stage();
Scene homescene;
Label namelabel=new Label();
MenuButton mb=new MenuButton();
//

//Registration Screen

Scene Regscene;


//VBoxes
static VBox vb=new VBox();
VBox vbs=new VBox();
VBox vbr=new VBox();
TranslateTransition t=new TranslateTransition(Duration.seconds(1),vb);
 static public ArrayList<Student> studentlist = new ArrayList();
 static public ArrayList<Teacher> Teacherlist = new ArrayList();
 int x;
 static int index;
 static int tindex;
// TEacher scene
 Scene teacherhomescene;
public void start(Stage stage) throws Exception {
	
	

Student ss=new Student();
ss.setEmail("1");
ss.setPassword("1");
ss.setName("Naeem");
ss.setType("student");
studentlist.add(ss);
//teachers
Teacher t1=new Teacher();
t1.setEmail("t1");
t1.setPassword("123456");
t1.setName("Muhammad Hassam Shakil");
t1.setType("Teacher");
t1.setGender("Male");
t1.setCourse("APPLIED PHYSICS");
Teacherlist.add(t1);
Teacher t2=new Teacher();
t2.setEmail("t2");
t2.setPassword("123456");
t2.setName("Ikram e Khuda");
t2.setGender("Male");
t2.setType("Teacher");
t2.setCourse("CALCULUS AND ANALYTICAL GEOMETRY");
Teacherlist.add(t2);
Teacher t3=new Teacher();
t3.setEmail("t3");
t3.setPassword("123456");
t3.setName("Zain Mir");
t3.setGender("Male");
t3.setType("Teacher");
t3.setCourse("APPLIED PHYSICS (LAB)");
Teacherlist.add(t3);
Teacher t4=new Teacher();
t4.setEmail("t4");
t4.setPassword("123456");
t4.setName("Alia Faruqui");
t4.setGender("Female");
t4.setType("Teacher");
t4.setCourse("FUNCTIONAL ENGLISH");
Teacherlist.add(t4);
Teacher t5=new Teacher();
t5.setEmail("t5");
t5.setPassword("123456");
t5.setName("Jamil Ahmed");
t5.setGender("Male");
t5.setType("Teacher");
t5.setCourse("INTRO TO INFO & COMMUNICATION TECH(LAB)");
Teacherlist.add(t5);
Teacher t6=new Teacher();
t6.setEmail("t6");
t6.setPassword("123456");
t6.setName("Muhammad Imani");
t6.setGender("Male");
t6.setType("Teacher");
t6.setCourse("INTRO TO INFO & COMMUNICATION TECH");
Teacherlist.add(t6);
Teacher t7=new Teacher();
t7.setEmail("t7");
t7.setPassword("123456");
t7.setName("Dr. Rahat Jehan");
t7.setGender("Female");
t7.setType("Teacher");
t7.setCourse("ISLAMIAT AND PAKISTAN STUDIES");
Teacherlist.add(t7);


signInLabel();
		  signUplabel();
		  vb.setPrefSize(480, 500);
		  vb.setStyle("-fx-background-color: white;"); vb.setLayoutY(-45);
		  vb.setLayoutX(14);
		  Signin();
		  register();
		  
			signup.setOnAction(e->
			{
				if(nametf.getText().isEmpty() ==true && rpf.getText().isEmpty()==true && emailtf.getText().isEmpty()==true) {
					Alert alert = new Alert(AlertType.WARNING);	
					alert.setContentText("Kindly fill all the areas.");
					alert.show();}
				else {
					Student s=new Student();
					s.setName(nametf.getText());
					s.setPassword(rpf.getText());
					s.setEmail(emailtf.getText());
					s.setBirthday(birth.getValue().toString());
			 if(tg.getSelectedToggle().equals(male))
			 {
				 s.setGender(male.getText());

			 }
			 else
			 {
				 s.setGender(female.getText());
			 }
					s.setDepartment(Department.getSelectionModel().getSelectedItem());
					s.setCampus("EDC TOWER");
					s.setPhonenumber(pn.getText());
					s.setType(type.getSelectionModel().getSelectedItem());

					studentlist.add(s);
					
					rpf.clear();
					emailtf.clear();
					nametf.clear();
					pn.clear();

					Alert alert = new Alert(AlertType.CONFIRMATION,"You have been registered Successfully !",null);	
					alert.show();
				}
				
			
			});
			
			signin.setOnAction(e->
			{
				
				//student login
			Student s=new Student();
			
			for( int x=0;x<studentlist.size();x++) {
	
			if(studentlist.get(x).email.equals(etf.getText()) && studentlist.get(x).password.equals(pf.getText()) && studentlist.get(x).type.equalsIgnoreCase("Student"))
			{
				index=x;	
				break;
			}
			}
			s=studentlist.get(index);
			if(s.email.equals(etf.getText()) && s.password.equals(pf.getText()) )
			{	
	mb.setText(s.getName());
mb.setTextAlignment(TextAlignment.CENTER);
mb.prefWidth(70);
mb.setTextFill(Color.WHITE);
mb.setFont(Font.font("Arial",FontWeight.BOLD , 14.0));
mb.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
//profile
pusername.setText(s.getName());
pemail.setText(s.getEmail());
pphone.setText(s.getPhonenumber());
pgender.setText(s.getGender());
pdob.setText(s.getBirthday());
pdept.setText(s.getDepartment());
pCampus.setText(s.getCampus());
Home();
}
			//student login
	Teacher t=new Teacher();
			
			for( int x=0;x<Teacherlist.size();x++) {
	
			if(Teacherlist.get(x).email.equals(etf.getText()) && Teacherlist.get(x).password.equals(pf.getText()) && Teacherlist.get(x).type.equals("Teacher"))
			{
				tindex=x;	
				break;
			}
			}
			t=Teacherlist.get(tindex);
			if(t.email.equals(etf.getText()) && t.password.equals(pf.getText()) )
			{	
	mb.setText(t.getName());
mb.setTextAlignment(TextAlignment.CENTER);
mb.prefWidth(40);
mb.setTextFill(Color.WHITE);
mb.setFont(Font.font("Arial",FontWeight.BOLD , 20.0));
mb.setBackground(new Background(new BackgroundFill(Color.MAGENTA, CornerRadii.EMPTY, Insets.EMPTY)));
///profil
pusername.setText(t.getName());
pemail.setText(t.getEmail());
pphone.setText(t.getPhonenumber());
pgender.setText(t.getGender());
pdob.setText(t.getBirthday());
pdept.setText(t.getDepartment());
pCampus.setText(t.getCampus());
teacherHomescene();
}
			
			else if(!s.getName().equals(etf.getText()) && !s.getPassword().equals(pf.getText()))
			{
				error.setText("Sign In failed");
				error.setTextFill(Color.RED);
			}
			else  if(etf.getText().equals(null) && pf.getText().equals(null))
			{
				System.out.print("empty");
			}

			});

			Logout.setOnAction(e-> {
				window.setScene(scene1);
				etf.clear();
				pf.clear();
				index=0;
				
				mb.getItems().clear();
			});
		  animation();
		  btn1.setOnAction(e->
		  {
			  vb.getChildren().removeAll();
			  animation2();
		  });

		  btn2.setOnAction(e->{
			  vb.getChildren().removeAll();
			  animation3();
		  });
		  pane.setStyle("-fx-background-color: #333333;"); 
		  pane.setLayoutY(100);
		  pane.setPrefSize(980, 400);
		  pane.getChildren().addAll(l1,l2,btn1,l3,l4,btn2,vb);
		  ap.getChildren().addAll(pane); scene1=new Scene(ap,980,680);
		  scene1.setFill(Color.TRANSPARENT);
		  window.setScene(scene1);
		window.setFullScreen(true);
		  window.show();		
	}
private void signUplabel()
{
	
	
	l1.setStyle("-fx-text-fill: #FFFFFF;-fx-font-weight: Bold;");
	l2.setTextFill(Color.WHITE);
	l1.setLayoutY(120);
	l2.setLayoutY(150);
	l2.setLayoutX(25);
	l1.setLayoutX(25);
	l2.setWrapText(true);
	l1.setFont(Font.font(20));
	l2.setFont(Font.font(14));
	btn1.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-border-color:#cccccc;-fx-border-radius:5px;-fx-border-width:2px;-fx-text-fill:whitesmoke;-fx-font-weight: Bold;");
	btn1.setLayoutY(210);
	btn1.setLayoutX(18);
	btn1.setPrefHeight(35);
	btn1.setPrefWidth(120);
	l2.setMinWidth(Region.USE_PREF_SIZE);
	l2.setMinHeight(Region.USE_PREF_SIZE);
	l2.setPrefWidth(250);
	
}

private void signInLabel()
{
	
	l3.setStyle("-fx-text-fill: #FFFFFF;-fx-font-weight: Bold;");
	l4.setTextFill(Color.WHITE);
	l3.setLayoutY(120);
	l4.setLayoutY(150);
	l4.setLayoutX(650);
	l3.setLayoutX(650);
	l4.setWrapText(true);
	l3.setFont(Font.font(20));
	l4.setFont(Font.font(14));
	btn2.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-border-color:#cccccc;-fx-border-radius:5px;-fx-border-width:2px;-fx-text-fill:whitesmoke;-fx-font-weight: Bold;");
	btn2.setLayoutY(210);
	btn2.setLayoutX(700);
	btn2.setPrefHeight(35);
	btn2.setPrefWidth(120);
	l4.setMinWidth(Region.USE_PREF_SIZE);
	l4.setMinHeight(Region.USE_PREF_SIZE);
	l4.setPrefWidth(250);
}


void Signin()
{
	Label smart_academy=new Label("SMART ACADEMY");
	
	etf.setStyle("-fx-background-color: transparent");
	HBox hb=new HBox();
	hb.setHgrow(etf, Priority.ALWAYS);
	etf.setMaxWidth(Double.MAX_VALUE);
	etf.setMaxHeight(Double.MAX_VALUE);
	etf.setPromptText("Email");
	hb.getChildren().add(etf);
	hb.setPrefHeight(45);
	//
	
	pf.setPromptText("Password");
	pf.setStyle("-fx-background-color: transparent");
	HBox hb2=new HBox();
	hb2.setHgrow(pf, Priority.ALWAYS);
	pf.setMaxWidth(Double.MAX_VALUE);
	pf.setMaxHeight(Double.MAX_VALUE);
	hb2.getChildren().add(pf);
	hb2.setPrefHeight(45);
	
	Button fp=new Button("Forgot Password?");
	fp.setFont(Font.font(15));
fp.setMaxWidth(Double.MAX_VALUE);
fp.setAlignment(Pos.CENTER_RIGHT);
fp.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:grey;-fx-font-size: 15px;");
	signin.setPrefSize(120, 39);
	signin.setStyle("-fx-background-color:lightslategray;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:15px;-fx-font-weight: Bold;");
	HBox hb3=new HBox();
	hb3.setAlignment(Pos.CENTER_RIGHT);
	hb3.setHgrow(fp,Priority.ALWAYS);
	hb3.getChildren().addAll(error,fp,signin);
	hb3.setPrefHeight(45);

	vbs.setMargin(hb, new Insets(20,15,0,15));
	vbs.setMargin(hb2, new Insets(20,15,0,15));
	vbs.setMargin(hb3, new Insets(20,15,0,15));
	vbs.setMargin(smart_academy, new Insets(20,15,0,15));
	vbs.setAlignment(Pos.CENTER_LEFT);
	hb.setStyle("-fx-background-color:Transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hb2.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hb3.setStyle("-fx-background-color:transparent;-fx-border-color:transparent;-fx-border-width:0px 0px 1px 0px");
	smart_academy.setStyle("-fx-text-fill: lightslategray;-fx-font-weight: Bold;");
	smart_academy.setFont(Font.font(20));
	vbs.setPrefSize(500, 500);
	smart_academy.setFont(Font.font("calibri",30));
	vbs.getChildren().addAll(smart_academy,hb,hb2,hb3);
	
}

@SuppressWarnings("static-access")
void register()
{
	HBox label=new HBox();
	Label smart_academy=new Label("SMART ACADEMY");
	label.getChildren().addAll(smart_academy);
	label.setAlignment(Pos.CENTER_LEFT);
	// Full name
	nametf.setStyle("-fx-background-color: transparent;");
	HBox hb=new HBox();
	hb.setHgrow(nametf, Priority.ALWAYS);
	nametf.setMaxWidth(Double.MAX_VALUE);
	nametf.setMaxHeight(Double.MAX_VALUE);
	nametf.setPromptText("Full Name");
	hb.getChildren().add(nametf);
	hb.setPrefHeight(45);
	
	//Email
	
	emailtf.setPromptText("Email");
	emailtf.setStyle("-fx-background-color: transparent;");
	HBox hb2=new HBox();
	hb2.setHgrow(emailtf, Priority.ALWAYS);
	emailtf.setMaxWidth(Double.MAX_VALUE);
	emailtf.setMaxHeight(Double.MAX_VALUE);
	hb2.getChildren().add(emailtf);
	hb2.setPrefHeight(45);
	//password
	
	rpf.setPromptText("Password");
	rpf.setStyle("-fx-background-color: transparent;");
	HBox hb3=new HBox();
	hb3.setHgrow(rpf, Priority.ALWAYS);
	rpf.setMaxWidth(Double.MAX_VALUE);
	rpf.setMaxHeight(Double.MAX_VALUE);
	hb3.getChildren().add(rpf);
	hb3.setPrefHeight(45);
	//
	Department.setPromptText("Department");
	Department.setStyle("-fx-background-color: transparent;");
	HBox hbd=new HBox();
	hbd.setHgrow(Department, Priority.ALWAYS);
	Department.setMaxWidth(Double.MAX_VALUE);
	Department.setMaxHeight(Double.MAX_VALUE);
	Department.setValue("FEST");
	hbd.getChildren().add(Department);
	hbd.setPrefHeight(45);
	//Type
	
	type.setPromptText("Type");
	type.setStyle("-fx-background-color: transparent;");
	HBox hbt=new HBox();
	hbt.setHgrow(type, Priority.ALWAYS);
	type.setMaxWidth(Double.MAX_VALUE);
	type.setMaxHeight(Double.MAX_VALUE);
	type.setValue("Student");
	hbt.getChildren().add(type);
	hbt.setPrefHeight(45);
	//phone number
	
	pn.setPromptText("Phone Number");
	pn.setStyle("-fx-background-color: transparent;");
	HBox hbpn=new HBox();
	hbpn.setHgrow(pn, Priority.ALWAYS);
	pn.setMaxWidth(Double.MAX_VALUE);
	pn.setMaxHeight(Double.MAX_VALUE);
	hbpn.getChildren().add(pn);
	hbpn.setPrefHeight(45);
	//
	HBox radio=new HBox();
	radio.setPadding(new Insets(10));
	radio.setSpacing(20);

	male.setStyle("-fx-text-fill: lightslategray;-fx-font-size:15px;-fx-font-weight: Bold;");
	female.setStyle("-fx-text-fill: lightslategray;-fx-font-size:15px;-fx-font-weight: Bold;");
male.setToggleGroup(tg);
female.setToggleGroup(tg);
male.setSelected(true);
	Label gender=new Label("Gender:");
	gender.setStyle("-fx-text-fill: lightslategray;-fx-font-size: 15px;-fx-font-weight: Bold;");
	radio.getChildren().addAll(gender,male,female);
	
    //
	HBox birthday=new HBox();
	Label Birthdaylabel=new Label("Date Of Birth:");
	Birthdaylabel.setStyle("-fx-text-fill: lightslategray;-fx-font-size:15px;-fx-font-weight: Bold;");
	birthday.setPadding(new Insets(10));
birthday.setSpacing(10);
birth.setValue(LocalDate.now());

	birthday.getChildren().addAll(Birthdaylabel,birth);
	//
	
	signup.setPrefSize(120, 39);
	signup.setStyle("-fx-background-color:lightslategray;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:15px;-fx-font-weight: Bold;");
	HBox hb5=new HBox();
	hb5.setAlignment(Pos.BOTTOM_RIGHT);
	hb5.getChildren().addAll(signup);
	hb5.setPrefHeight(45);
//

	vbr.setMargin(hb, new Insets(20,15,0,15));
	vbr.setMargin(hb2, new Insets(20,15,0,15));
	vbr.setMargin(hb3, new Insets(20,15,0,15));
	vbr.setMargin(hb5, new Insets(20,15,0,15));
	vbr.setMargin(hbd, new Insets(20,15,0,15));
	vbr.setMargin(hbt, new Insets(20,15,0,15));
	vbr.setMargin(hbpn, new Insets(20,15,0,15));
	vbr.setMargin(label, new Insets(20,15,0,15));
	vbr.setMargin(radio, new Insets(20,15,0,15));
	vbr.setMargin(birthday, new Insets(20,15,0,15));
	vbr.setAlignment(Pos.BOTTOM_RIGHT);
	hb.setStyle("-fx-background-color:Transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hb2.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hb3.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hbd.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hbt.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	hbpn.setStyle("-fx-background-color:transparent;-fx-border-color:lightslategray;-fx-border-width:0px 0px 1px 0px");
	radio.setStyle("-fx-background-color:transparent;-fx-border-color:transparent;-fx-border-width:0px 0px 1px 0px");
	smart_academy.setStyle("-fx-text-fill: lightslategray;-fx-font-weight: Bold;");
	smart_academy.setFont(Font.font("calibri",30));
	vbr.setPrefSize(450, 450);
	vbr.getChildren().addAll(label,hb,hb2,hb3,hbpn,hbd,hbt,radio,birthday,hb5);

}

final void  animation()
{
	t.setToX(vb.getLayoutX() *33);
	t.play();
	t.setOnFinished((e)->{
		vb.getChildren().clear();
		vb.getChildren().setAll(vbs);
		
	});
}
	
final void animation2()
	{
		t.setToX(2);
		t.play();
		t.setOnFinished((e)->{
			vb.getChildren().setAll(vbr);
		});
	}
	
final void animation3()
		{
			t.setToX(vb.getLayoutX() *33);
			t.play();
			t.setOnFinished((e)->{
				vb.getChildren().setAll(vbs);
			});
		}


VBox sch=new VBox();
void Home()
{
	BorderPane bp=new BorderPane();
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	Label menul=new Label("  MENU");
	menul.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	//
	Button registrationb=new Button("REGISTRATION");
	registrationb.setOnMouseEntered(e-> registrationb.setStyle("-fx-background-color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	registrationb.setOnMouseExited(e-> registrationb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	registrationb.setOnAction(e->{semester1.clear();Registrationscene();});
	
	Button examresultb=new Button("EXAM RESULT");
	examresultb.setOnMouseEntered(e-> examresultb.setStyle("-fx-background-color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	examresultb.setOnMouseExited(e-> examresultb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	examresultb.setOnAction(e->{
		resultView();
	});
	Button attb=new Button("ATTENDANCE");
	attb.setOnMouseEntered(e-> attb.setStyle("-fx-background-Color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	attb.setOnMouseExited(e-> attb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	attb.setOnAction(e->{
		attandenceview();
	});
	Button semescheduleb=new Button("SEMESTER SCHEDULE");
	semescheduleb.setOnMouseEntered(e-> semescheduleb.setStyle("-fx-background-Color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	semescheduleb.setOnMouseExited(e-> semescheduleb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	
	//semester Button Event!
	semescheduleb.setOnAction(e->{
		
	semesterschedule();});
	//
	registrationb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	examresultb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	attb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	semescheduleb.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	//
	VBox panel=new VBox(35);
	panel.setStyle("-fx-background-color: gray; ");
	panel.setPrefSize(250, 500);
	panel.setLayoutY(300);
	panel.setLayoutX(-200);
	panel.setPadding(new Insets(5,5,5,5));
	panel.getChildren().addAll(menul,registrationb,examresultb,attb,semescheduleb);
	//
	Image menu=new Image("images//menu-512.png");
	ImageView menuv=new ImageView(menu);
	
	menuv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	
	Image regicon=new Image("images//register-icon.png");
	ImageView iv2=new ImageView(regicon);
	iv2.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	Image ericon=new Image("images//result-512.png");
	ImageView eriv=new ImageView(ericon);
	eriv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	Image att=new Image("images//attandance.png");
	ImageView attv=new ImageView(att);
	attv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	Image semschedule=new Image("images//semester-schedule.png");
	ImageView semschedulev=new ImageView(semschedule);
	semschedulev.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	semschedulev.setStyle("-fx-background-color: transparent;");
	menuv.setOnMouseClicked(e-> {
		TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
		ts.setToX(-250);
		ts.play();
	});
	
	//Calender
	Image cali=new Image("images//cadetblue-calendar-icon.png");
	ImageView calv=new ImageView(cali);
	Label cal=new Label("CALENDAR");
cal.setTextFill(Color.GRAY);
cal.setTextAlignment(TextAlignment.CENTER);
cal.setAlignment(Pos.CENTER_RIGHT);
//CalendarPicker cp=new CalendarPicker();

	HBox hb=new HBox(10);
	hb.getChildren().addAll(calv,cal);
	VBox calender=new VBox(10);
	calender.setStyle("-fx-background-color: transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
calender.getChildren().addAll(hb);
calender.setLayoutX(980);
calender.setLayoutY(300);
calender.setPadding(new Insets(5,5,5,5));
//Events

Label event=new Label("EVENTS");
event.setTextFill(Color.GRAY);
event.setTextAlignment(TextAlignment.CENTER);
event.setAlignment(Pos.CENTER_RIGHT);
	HBox hb2=new HBox(10);
	hb2.getChildren().addAll(new ImageView(new Image("images//cadetblue-calendar-icon.png")),event);
	VBox events=new VBox(10);
	events.setStyle("-fx-background-color: transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	events.getChildren().addAll(hb2);
	events.setLayoutX(980);
	events.setLayoutY(710);
	events.setPrefSize(417, 250);
	events.setPadding(new Insets(5,5,5,5));
	//
	VBox sidemenu=new VBox();
	sidemenu.setSpacing(25);
	sidemenu.getChildren().addAll(menuv,iv2,eriv,attv,semschedulev);
	sidemenu.setPrefSize(50, 500);

	sidemenu.setStyle("-fx-background-color: gray; ");

	
	Logout.setStyle("-fx-text-fill: Black;-fx-background-color: White;-fx-font-weight: Bold;");
	
	Pane home=new Pane();
	
	Text powered=new Text("Powered By : Faizan");
	powered.setStyle("-fx-text-fill: Black;-fx-font-size: 15px; -fx-font-weight: Bold");
	Label l=new Label("9 2009-2018. All Rights Reserved By SMART ACADEMY");
	l.setStyle("-fx-text-fill: White;-fx-font-size: 15px;");
	
	//bottom bar
	HBox bottom=new HBox(900);
	bottom.setStyle("-fx-background-color: gray;-fx-font-weight:Bold;");
	bottom.getChildren().addAll(l,powered);
	bottom.setLayoutY(980);
	bottom.setPrefWidth(1402);
	bottom.setPrefHeight(50);

	bp.setTop(iv);
	sidemenu.setLayoutY(300);
	sidemenu.setLayoutX(0);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	
	
	mb.setPadding(new Insets(5,5,5,5));
	mb.getItems().addAll(Logout);
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button sic=new Button("  SIC");
	sic.setPrefWidth(100);
	sic.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	sic.setAlignment(Pos.CENTER_LEFT);
	fade(sic);
	fademenu(mb);

	sic.setOnAction(e->{
		window.setScene(homescene);
		window.setFullScreen(true);
		
	});
	
ScrollPane sp=new ScrollPane(home);
	hb1.getChildren().addAll(sic,mb);
	home.getChildren().addAll(bp,hb1,panel,sidemenu,bottom,calender,events,profile());
	homescene=new Scene(sp,1402,1000);
	window.setScene(homescene);
	window.setFullScreen(true);
	
}

public void fade(Button control) {


    final FadeTransition fadeIn = new FadeTransition(Duration.millis(100));
    fadeIn.setNode(control);
    fadeIn.setToValue(1);
    control.setOnMouseEntered(e -> fadeIn.playFromStart());

    final FadeTransition fadeOut = new FadeTransition(Duration.millis(100));
    fadeOut.setNode(control);
    fadeOut.setToValue(0.5);
    control.setOnMouseExited(e -> fadeOut.playFromStart());

    control.setOpacity(3);
}
public void fademenu(MenuButton control) {


    final FadeTransition fadeIn = new FadeTransition(Duration.millis(100));
    fadeIn.setNode(control);
    fadeIn.setToValue(1);
    control.setOnMouseEntered(e -> fadeIn.playFromStart());

    final FadeTransition fadeOut = new FadeTransition(Duration.millis(100));
    fadeOut.setNode(control);
    fadeOut.setToValue(0.5);
    control.setOnMouseExited(e -> fadeOut.playFromStart());

    control.setOpacity(3);
}

VBox profile()
{
	Label Profile=new Label("PROFILE");
	Profile.setLayoutX(1000);
	Profile.setLayoutX(370);
	Profile.setUnderline(true);
	Profile.setStyle("-fx-background-color:transparent; -fx-text-fill: gray;-fx-font-size:40px;-fx-font-weight: Bold;");
	Label username,email,phone,gender,dob,dept,Campus;
	username=new Label("Name: ");
	email=new Label("Email Address: ");
	phone=new Label("Phone Number: ");
	gender=new Label("Gender: ");
	dob=new Label("Date of Birth: ");
	dept=new Label("Department: ");
	Campus=new Label("Campus: ");
	HBox hb1=new HBox(20);
	hb1.getChildren().addAll(username,pusername);
	hb1.setPadding(new Insets(5,5,5,5));
	HBox hb2=new HBox(20);
	hb2.getChildren().addAll(email,pemail);
	hb2.setPadding(new Insets(5,5,5,5));
	HBox hb3=new HBox(20);
	hb3.getChildren().addAll(phone,pphone);
	hb3.setPadding(new Insets(5,5,5,5));
	HBox hb4=new HBox(20);
	hb4.getChildren().addAll(gender,pgender);
	hb4.setPadding(new Insets(5,5,5,5));
	HBox hb5=new HBox(20);
	hb5.getChildren().addAll(dob,pdob);
	hb5.setPadding(new Insets(5,5,5,5));
	HBox hb6=new HBox(20);
	hb6.getChildren().addAll(dept,pdept);
	hb6.setPadding(new Insets(5,5,5,5));
	HBox hb7=new HBox(20);
	hb7.getChildren().addAll(Campus,pCampus);
	hb7.setPadding(new Insets(5,5,5,5));
	hb1.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");	
	hb2.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb3.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb4.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb5.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb6.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb7.setStyle("-fx-background-color:transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	hb1.setPrefWidth(600);
	VBox vb=new VBox(10);
	vb.getChildren().addAll(Profile,hb1,hb2,hb3,hb4,hb5,hb6,hb7);
	vb.setLayoutX(330);
	vb.setLayoutY(365);
	return vb;
 
	
}
 ObservableList<Course> semester1=FXCollections.observableArrayList();
 ObservableList<Course> semester2=FXCollections.observableArrayList();
 ObservableList<Course> semester3=FXCollections.observableArrayList();
 static Button back=new Button("back");


 Student st=new Student();
 Course s1c1,s1c2,s1c3,s1c4,s1c5,s1c6,s1c7;
void Registrationscene()
{
	
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button sic=new Button("  SIC");
	sic.setPrefWidth(100);
	sic.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	sic.setAlignment(Pos.CENTER_LEFT);
	sic.setOnAction(e->{
		window.setScene(homescene);
		window.setFullScreen(true);
	});
	fade(sic);
	fademenu(mb);
	hb1.getChildren().addAll(sic,mb);
	
	AnchorPane p=new AnchorPane();
	
	VBox vbox=new VBox(3);
	
	ScrollBar sb=new ScrollBar();
	
	vbox.setLayoutX(49);
	vbox.setLayoutY(300);
	s1c1=new Course("APPLIED PHYSICS", "to be taken", "MUHAMMAD HASSAM SHAKIL", "-", "SEN101", "Mon 8:30-11:30", 3);
	s1c2=new Course("APPLIED PHYSICS (LAB)", "to be taken", "MUHAMMAD ZAIN MIR", "-", "SEN101-L", "Mon 11:45-14:45", 1);
	s1c3=new Course("CALCULUS AND ANALYTICAL GEOMETRY", "to be taken", "IKRAM E KHUDA", "-", "SEN102", "Tue 8:30-11:30", 3);
	s1c4=new Course("FUNCTIONAL ENGLISH", "to be taken", "Alia Faroqui", "-", "HUM111", "Tue 8:30-11:30", 3);
	s1c5=new Course("INTRO TO INFO & COMMUNICATION TECH(LAB)", "to be taken", "JAMIL AHMED MEMON", "-", "CSC111-L", "Wed 8:30-10:30", 1);
	s1c6=new Course("INTRO TO INFORMATION & COMMUNICATION TECH", "to be taken", "MUHAMMAD IMANI", "-", "CSC111", "Thu 8:30-11:30", 3);
	s1c7=new Course("ISLAMIAT AND PAKISTAN STUDIES", "to be taken", "DR. RAHAT JEHAN", "-", "HUM122", "Thu 11:45-14:45", 3);
	semester1.addAll(s1c1,s1c2,s1c3,s1c4,s1c5,s1c6,s1c7);
	Semester s1=new Semester();
	s1.semester(semester1, "Semester-1");
	
	Button register=new Button("REGISTER");
	register.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 15px;");
	register.setLayoutY(980);
	register.setLayoutX(500);
// Register EVENT ....
	register.setOnAction(e->{
		
		studentlist.get(index).courses.clear();
		
	if(s1c1.checkb.isSelected()==true) {
		studentlist.get(index).courses.add(s1c1);
	}

if(s1c2.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c2);
	}
if(s1c3.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c3);
}
if(s1c4.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c4);
}
if(s1c5.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c5);
}
if(s1c6.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c6);
}
if(s1c7.checkb.isSelected()==true) {
	studentlist.get(index).courses.add(s1c7);
}
s1c1.checkb.setSelected(false);
s1c2.checkb.setSelected(false);
s1c3.checkb.setSelected(false);
s1c4.checkb.setSelected(false);
s1c5.checkb.setSelected(false);
s1c6.checkb.setSelected(false);
s1c7.checkb.setSelected(false);

	Alert a=new Alert(AlertType.INFORMATION);
	a.setContentText("Course(s) has/have been registered!!!");
	a.show();
			
	
});
for(x=0;x<s1.vblist.size();x++)
{
	VBox vb=new VBox();
	vb.getChildren().add(s1.vblist.get(x));
	vbox.getChildren().add(vb);

}


vbox.getChildren().add(register);
ScrollPane sp=new ScrollPane(p);
vbox.setStyle("-fx-border-width: 2px; -fx-border-color: black");
vbox.setPadding(new Insets(5,5,5,5));
sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
sp.setPrefHeight(1000);
vbox.setPrefHeight(Control.USE_COMPUTED_SIZE);
vbox.setMaxHeight(Double.MAX_VALUE);

p.getChildren().addAll(hb1,bp,vbox);
 Regscene=new Scene(sp,1402,1000);
 window.setScene(Regscene);
 window.setFullScreen(true);
}


VBox b=new VBox();

Label lcname,lcteacher,lctt;
HBox hcname,hcteacher,hctt,HBOX;
void semesterschedule()
{
	VBox schedulevbox=new VBox();
	VBox vb=new VBox();
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button sic=new Button("  SIC");
	sic.setPrefWidth(100);
	sic.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	sic.setAlignment(Pos.CENTER_LEFT);
	sic.setOnAction(e->{
		window.setScene(homescene);
		window.setFullScreen(true);
	});
	fade(sic);
	fademenu(mb);
	hb1.getChildren().addAll(sic,mb);
	
	AnchorPane p=new AnchorPane();
	
ScrollPane sp=new ScrollPane(p);
schedulevbox.setStyle("-fx-border-width: 2px; -fx-border-color: black");
schedulevbox.setPadding(new Insets(5,5,5,5));
sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
sp.setPrefHeight(100);
schedulevbox.setPrefHeight(Control.USE_COMPUTED_SIZE);
schedulevbox.setMaxHeight(Double.MAX_VALUE);

Label cn=new Label();
Label teach=new Label();
Label Tt=new Label();
HBox coursename=new HBox();
coursename.getChildren().add(cn);
coursename.setPadding(new Insets(5,5,5,5));
coursename.setPrefWidth(380);
coursename.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
HBox Teacher=new HBox();
Teacher.getChildren().add(teach);
Teacher.setPadding(new Insets(5,5,5,5));
Teacher.setPrefWidth(200);
Teacher.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
HBox TimeTable=new HBox();
TimeTable.getChildren().add(Tt);
TimeTable.setPadding(new Insets(5,5,5,5));
TimeTable.setPrefWidth(200);
TimeTable.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");

HBox setschedule=new HBox();
setschedule.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: black;-fx-background-color: gray;");
Label Schedule=new Label("SCHEDULE");
Schedule.setTextFill(Color.GRAY);
Schedule.setStyle("-fx-text-fill: gray; -fx-font-weight:Bold; -fx-font-size: 30px;");
schedulevbox.getChildren().addAll(Schedule);
for(int x=0;x<studentlist.get(index).courses.size();x++) {
	
	lcname=new Label(studentlist.get(index).courses.get(x).getName());
	lcname.setTextFill(Color.BLACK);
	lcname.setFont(Font.font(20));
	lcteacher=new Label(studentlist.get(index).courses.get(x).getTeacher());
	lcteacher.setTextFill(Color.BLACK);
	lcteacher.setFont(Font.font(20));
 lctt=new Label(studentlist.get(index).courses.get(x).getTimetable());
 lctt.setTextFill(Color.BLACK);
 lctt.setFont(Font.font(25));
 hcname=new HBox();
 hcname.setPadding(new Insets(5,5,5,5));
 hcname.setPrefWidth(480);
 hcname.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
 hcname.getChildren().add(lcname);
 hcteacher=new HBox();
 hcteacher.setPadding(new Insets(5,5,5,5));
 hcteacher.setPrefWidth(200);
 hcteacher.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
 hcteacher.getChildren().add(lcteacher);
 hctt=new HBox();
 hctt.setPadding(new Insets(5,5,5,5));
 hctt.setPrefWidth(250);
 hctt.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
 hctt.getChildren().add(lctt);
 HBOX=new HBox(1);
 HBOX.getChildren().addAll(hcname,hcteacher,hctt);
schedulevbox.getChildren().addAll(HBOX);

}


schedulevbox.setLayoutX(300);
schedulevbox.setLayoutY(430);
p.getChildren().addAll(hb1,bp,schedulevbox);
 smschedule=new Scene(sp,1402,1000);

 window.setScene(smschedule);
 window.setFullScreen(true);
}


void teacherHomescene()
{
	mb.setPadding(new Insets(5,5,5,5));
	mb.getItems().addAll(Logout);
	BorderPane bp=new BorderPane();
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	Label menul=new Label("  MENU");
	menul.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	//
	Button Attandence=new Button("TAKE ATTANDENCE");
	Attandence.setOnMouseEntered(e-> Attandence.setStyle("-fx-background-color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	Attandence.setOnMouseExited(e-> Attandence.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	Attandence.setOnAction(e->{
		
		attandenceScene();
	});
	Button updateMarks=new Button("MARKS UPDATE");
	updateMarks.setOnMouseEntered(e-> updateMarks.setStyle("-fx-background-color: transparent; -fx-background-radius: 5px; -fx-text-fill:black; -fx-font-size:20px; -fx-font-weight: Bold;"));
	updateMarks.setOnMouseExited(e-> updateMarks.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;"));
	
	updateMarks.setOnAction(e->{
		
		updateResult();
	});
	
	Attandence.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	updateMarks.setStyle("-fx-background-color:transparent;-fx-background-radius:5px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;");
	//
	VBox panel=new VBox(35);
	panel.setStyle("-fx-background-color: gray; ");
	panel.setPrefSize(250, 500);
	panel.setLayoutY(300);
	panel.setLayoutX(-200);
	panel.setPadding(new Insets(5,5,5,5));
	panel.getChildren().addAll(menul,Attandence,updateMarks);
	//
	Image menu=new Image("images//menu-512.png");
	ImageView menuv=new ImageView(menu);
	
	menuv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	
	Image regicon=new Image("images//register-icon.png");
	ImageView iv2=new ImageView(regicon);
	Image ericon=new Image("images//result-512.png");
	ImageView eriv=new ImageView(ericon);
	eriv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	Image att=new Image("images//attandance.png");
	ImageView attv=new ImageView(att);
	attv.setOnMouseEntered(e->{TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
	ts.setToX(250);
	ts.play();});
	menuv.setOnMouseClicked(e-> {
		TranslateTransition ts=new TranslateTransition(Duration.seconds(1), panel);
		ts.setToX(-250);
		ts.play();
	});
	
	//Calender
	Image cali=new Image("images//cadetblue-calendar-icon.png");
	ImageView calv=new ImageView(cali);
	Label cal=new Label("CALENDAR");
cal.setTextFill(Color.GRAY);
cal.setTextAlignment(TextAlignment.CENTER);
cal.setAlignment(Pos.CENTER_RIGHT);
//CalendarPicker cp=new CalendarPicker();
	HBox hb=new HBox(10);
	hb.getChildren().addAll(calv,cal);
	VBox calender=new VBox(10);
	calender.setStyle("-fx-background-color: transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
calender.getChildren().addAll(hb);
calender.setLayoutX(980);
calender.setLayoutY(300);
calender.setPadding(new Insets(5,5,5,5));
//Events

Label event=new Label("EVENTS");
event.setTextFill(Color.GRAY);
event.setTextAlignment(TextAlignment.CENTER);
event.setAlignment(Pos.CENTER_RIGHT);
	HBox hb2=new HBox(10);
	hb2.getChildren().addAll(new ImageView(new Image("images//cadetblue-calendar-icon.png")),event);
	VBox events=new VBox(10);
	events.setStyle("-fx-background-color: transparent;-fx-background-radius:3px;-fx-text-fill:#FFFFFF;-fx-font-size:20px;-fx-font-weight: Bold;-fx-border-color: gray;-fx-border-width: 2px;");
	events.getChildren().addAll(hb2);
	events.setLayoutX(980);
	events.setLayoutY(710);
	events.setPrefSize(417, 250);
	events.setPadding(new Insets(5,5,5,5));
	//
	VBox sidemenu=new VBox();
	sidemenu.setSpacing(25);
	sidemenu.getChildren().addAll(menuv,iv2,eriv);
	sidemenu.setPrefSize(50, 500);

	sidemenu.setStyle("-fx-background-color: gray; ");
	MenuItem settings=new MenuItem("Settings");
	settings.setStyle("-fx-text-fill: Black;-fx-background-color: White;-fx-font-weight: Bold;");
	
	Logout.setStyle("-fx-text-fill: Black;-fx-background-color: White;-fx-font-weight: Bold;");
	
	Pane home=new Pane();
	
	Label l=new Label("2009-2019. All Rights Reserved By SMART ACADEMY");
	l.setStyle("-fx-text-fill: White;-fx-font-size: 15px;");
	
	//bottom bar
	HBox bottom=new HBox(900);
	bottom.setStyle("-fx-background-color: gray;-fx-font-weight:Bold;");
	bottom.getChildren().addAll(l);
	bottom.setLayoutY(980);
	bottom.setPrefWidth(1402);
	bottom.setPrefHeight(50);

	bp.setTop(iv);
	sidemenu.setLayoutY(300);
	sidemenu.setLayoutX(0);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	
	
	
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button FIC=new Button("  FIC");
	FIC.setPrefWidth(100);
	FIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	FIC.setAlignment(Pos.CENTER_LEFT);
	fade(FIC);
	fademenu(mb);
	
	hb1.getChildren().addAll(FIC,mb);
	home.getChildren().addAll(bp,hb1,panel,sidemenu,bottom,calender,events,profile());
	ScrollPane sp=new ScrollPane(home);
	teacherhomescene=new Scene(sp,1402,1000);
	window.setScene(teacherhomescene);
	window.setFullScreen(true);
	FIC.setOnAction(e->{
		window.setScene(teacherhomescene);
		window.setFullScreen(true);
	});
}
Scene attandencescene;
Menu lectures=new Menu("Lectures");
MenuItem lect1=new MenuItem("lecture1");
MenuItem lect2=new MenuItem("lecture2");
MenuItem lect3=new MenuItem("lecture3");
MenuItem lect4=new MenuItem("lecture4");
MenuItem lect5=new MenuItem("lecture5");

HBox chechbox;
int sss,ccc;
MenuBar MB=new MenuBar(lectures);
void attandenceScene()
{
	
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button FIC=new Button("  FIC");
	FIC.setPrefWidth(100);
	FIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	FIC.setAlignment(Pos.CENTER_LEFT);
	FIC.setOnAction(e->{
		window.setScene(teacherhomescene);
		window.setFullScreen(true);
	});
	fade(FIC);
	fademenu(mb);
	hb1.getChildren().addAll(FIC,mb);
	
	AnchorPane p=new AnchorPane();
	
	VBox vbox=new VBox(3);
	
	
	
	lsattname=new Label("COURSE NAME");
	lsattlecture=new Label("DATE");
	lsattDate=new Label("LECTURE");
	//Label Colors
	lsattname.setTextFill(Color.WHITESMOKE);
	lsattlecture.setTextFill(Color.WHITESMOKE);
	lsattDate.setTextFill(Color.WHITESMOKE);
	//Label fonts
	lsattname.setFont(Font.font("Arial",21));
	lsattlecture.setFont(Font.font("Arial",21));
	lsattDate.setFont(Font.font("Arial",21));

	// Label's HBox
	Hsattname=new HBox();
	Hsattlecture=new HBox();
	HsattDate=new HBox();

	Hcomplete1=new HBox();
	// Label's HBOX ....
	//
	Hsattname.setPadding(new Insets(5,5,5,5));
	Hsattname.setPrefWidth(400);
	Hsattname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattname.getChildren().add(lsattname);
	
	Hsattlecture.setPadding(new Insets(5,5,5,5));
	Hsattlecture.setPrefWidth(300);
	Hsattlecture.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattlecture.getChildren().add(lsattlecture);
	
	HsattDate.setPadding(new Insets(5,5,5,5));
	HsattDate.setPrefWidth(300);
	HsattDate.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	HsattDate.getChildren().add(lsattDate);
	
	Hcomplete2=new HBox();
	Hcomplete2.getChildren().addAll(Hsattname,Hsattlecture,HsattDate);
	vbox.getChildren().add(Hcomplete2);
	
	
	
	
	
//	lsattname=new Label(studentlist.get(sss).courses.get(ccc).getName());
	
	//Label Colors
	lsattname.setTextFill(Color.WHITESMOKE);

	//Label fonts
	lsattname.setFont(Font.font("Arial",21));


	// Label's HBox
	Hsattname=new HBox();
	Hsattlecture=new HBox();
	HsattDate=new HBox();

	Hcomplete1=new HBox();
	// Label's HBOX ....
	//
	Hsattname.setPadding(new Insets(5,5,5,5));
	Hsattname.setPrefWidth(400);
	Hsattname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	//Hsattname.getChildren().addAl();
	
	Hsattlecture.setPadding(new Insets(5,5,5,5));
	Hsattlecture.setPrefWidth(300);
	Hsattlecture.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattlecture.getChildren().add(MB);
	
	HsattDate.setPadding(new Insets(5,5,5,5));
	HsattDate.setPrefWidth(300);
	HsattDate.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	HsattDate.getChildren().add(new DatePicker());
	
	Hcomplete2=new HBox();
	Hcomplete2.getChildren().addAll(Hsattname,HsattDate,Hsattlecture);
	lectures.getItems().addAll(lect1,lect2,lect3,lect4,lect5);
	lect1.setOnAction(e->{
		add.setDisable(false);
		  courseButtonaction();
	});
	lect2.setOnAction(e->{
		add.setDisable(false);
		  courseButtonaction();
	});
	lect3.setOnAction(e->{
		add.setDisable(false);
		  courseButtonaction();
	});
	lect4.setOnAction(e->{
		add.setDisable(false);
		  courseButtonaction();
	});
	lect5.setOnAction(e->{
		add.setDisable(false);
		  courseButtonaction();
	});
	vbox.getChildren().add(Hcomplete2);
  
		
	
	
	


ScrollPane sp=new ScrollPane(p);
vbox.setStyle("-fx-border-width: 2px; -fx-border-color: black");
vbox.setPadding(new Insets(5,5,5,5));
sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
sp.setPrefHeight(1000);
vbox.setPrefHeight(Control.USE_COMPUTED_SIZE);
vbox.setMaxHeight(Double.MAX_VALUE);
vbox.setLayoutX(200);
vbox.setLayoutY(300);


p.getChildren().addAll(bp,hb1,vbox);
 attandencescene=new Scene(sp,1402,1000);
 window.setScene(attandencescene);
 window.setFullScreen(true);
}

Scene cbscene;
Label attname;
CheckBox markatt=new CheckBox();;
HBox atthbox;
HBox acnamebox,checkbox;

static int cindex;
Label lsattname,lsattlecture,lsattDate;
HBox Hsattname,Hsattlecture,HsattDate,Hcomplete2;
Button add=new Button("ADD");
Boolean lec1=true,lec2=true,lec3=true,lec4=true,lec5=true,lec6=true,lec7=true;

void courseButtonaction()
{

	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	HBox hb1=new HBox();
	hb1.setPrefHeight(45);
	hb1.setPrefWidth(1380);
	hb1.setSpacing(990);
	hb1.setLayoutX(14);
	hb1.setLayoutY(214);
	hb1.setPadding(new Insets(5,5,5,5));
	hb1.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button FIC=new Button("  FIC");
	FIC.setPrefWidth(100);
	FIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	FIC.setAlignment(Pos.CENTER_LEFT);
	FIC.setOnAction(e->{
		window.setScene(teacherhomescene);
		window.setFullScreen(true);
	});
	fade(FIC);
	fademenu(mb);
	hb1.getChildren().addAll(FIC,mb);
	
	AnchorPane p=new AnchorPane();
	
	VBox vbox=new VBox(3);
	
	
	
	add.setOnAction(e->{
		for(int x=0;x<studentlist.size();x++)
		{
			for(int y=0;y<studentlist.get(x).courses.size();y++)
			{
				
		if(Teacherlist.get(tindex).getCourse().equalsIgnoreCase(studentlist.get(x).courses.get(y).getName()))
		{
			
			if(studentlist.get(x).courses.get(y).markatt.isSelected()==true)
			{
				
				studentlist.get(x).courses.get(y).present++;
				System.out.println();
				
			}
			else if(studentlist.get(x).courses.get(y).markatt.isSelected()==false)
			{
				studentlist.get(x).courses.get(y).absent++;
			}
			studentlist.get(x).courses.get(y).markatt.setSelected(false);
			
		}
		
		}
	}
	});
	lsattname=new Label("COURSE NAME");
	lsattlecture=new Label("DATE");
	lsattDate=new Label("LECTURE");
	//Label Colors
	lsattname.setTextFill(Color.WHITESMOKE);
	lsattlecture.setTextFill(Color.WHITESMOKE);
	lsattDate.setTextFill(Color.WHITESMOKE);
	//Label fonts
	lsattname.setFont(Font.font("Arial",21));
	lsattlecture.setFont(Font.font("Arial",21));
	lsattDate.setFont(Font.font("Arial",21));

	// Label's HBox
	Hsattname=new HBox();
	Hsattlecture=new HBox();
	HsattDate=new HBox();

	Hcomplete1=new HBox();
	// Label's HBOX ....
	//
	Hsattname.setPadding(new Insets(5,5,5,5));
	Hsattname.setPrefWidth(400);
	Hsattname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattname.getChildren().add(lsattname);
	
	Hsattlecture.setPadding(new Insets(5,5,5,5));
	Hsattlecture.setPrefWidth(300);
	Hsattlecture.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattlecture.getChildren().add(lsattlecture);
	
	HsattDate.setPadding(new Insets(5,5,5,5));
	HsattDate.setPrefWidth(300);
	HsattDate.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	HsattDate.getChildren().add(lsattDate);
	
	Hcomplete2=new HBox();
	Hcomplete2.getChildren().addAll(Hsattname,Hsattlecture,HsattDate);
	vbox.getChildren().add(Hcomplete2);
	
	
	
	
	
//	lsattname=new Label(studentlist.get(sss).courses.get(ccc).getName());
	
	//Label Colors
	lsattname.setTextFill(Color.WHITESMOKE);

	//Label fonts
	lsattname.setFont(Font.font("Arial",21));


	// Label's HBox
	Hsattname=new HBox();
	Hsattlecture=new HBox();
	HsattDate=new HBox();

	Hcomplete1=new HBox();
	// Label's HBOX ....
	//
	Hsattname.setPadding(new Insets(5,5,5,5));
	Hsattname.setPrefWidth(400);
	Hsattname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	//Hsattname.getChildren().addAl();
	
	Hsattlecture.setPadding(new Insets(5,5,5,5));
	Hsattlecture.setPrefWidth(300);
	Hsattlecture.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Hsattlecture.getChildren().add(MB);
	
	HsattDate.setPadding(new Insets(5,5,5,5));
	HsattDate.setPrefWidth(300);
	HsattDate.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	HsattDate.getChildren().add(new DatePicker());
	
	Hcomplete2=new HBox();
	Hcomplete2.getChildren().addAll(Hsattname,HsattDate,Hsattlecture);
	
	vbox.getChildren().add(Hcomplete2);

        	for(int x=0;x<studentlist.size();x++)
    		{
    			for(int y=0;y<studentlist.get(x).courses.size();y++)
    			{
    		if(Teacherlist.get(tindex).getCourse().equalsIgnoreCase(studentlist.get(x).courses.get(y).getName()))
    		{
    			checkbox=new HBox();
    			checkbox.setPadding(new Insets(5,5,5,5));
    			
    			checkbox.getChildren().add(studentlist.get(x).courses.get(y).markatt);
    			lsattname=new Label(studentlist.get(x).getName());
    			//Label Colors
    			lsattname.setTextFill(Color.WHITESMOKE);
    		
    			//Label fonts
    			lsattname.setFont(Font.font("Arial",21));


    			// Label's HBox
    			Hsattname=new HBox(200);
    			Hsattlecture=new HBox();
    			HsattDate=new HBox();

    			Hcomplete1=new HBox();
    			// Label's HBOX ....
    			//
    			Hsattname.setPadding(new Insets(7,5,5,5));
    			Hsattname.setPrefWidth(350);
    			Hsattname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
    			Hsattname.getChildren().addAll(lsattname,checkbox);
    			
    			HBox hb=new HBox();
    			hb.setPadding(new Insets(5,5,5,5));
    			hb.setPrefWidth(400);
    			hb.setStyle("-fx-font-width: Bold;-fx-border-width: 0px;-fx-background-color: transparent;");
    			HBox hb2=new HBox();
    			hb2.setPadding(new Insets(5,5,5,5));
    			hb2.setPrefWidth(400);
    			hb2.setStyle("-fx-font-width: Bold;-fx-border-width: 0px;-fx-background-color: transparent;");
    			
    			Hcomplete2=new HBox();
    			Hcomplete2.getChildren().addAll(hb1,hb2,Hsattname,add);
    			
    			vbox.getChildren().add(Hcomplete2);
    			
    			
    		}
    			}
    	}


ScrollPane sp=new ScrollPane(p);
vbox.setStyle("-fx-border-width: 2px; -fx-border-color: black");
vbox.setPadding(new Insets(5,5,5,5));
sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
sp.setPrefHeight(1000);
vbox.setPrefHeight(Control.USE_COMPUTED_SIZE);
vbox.setMaxHeight(Double.MAX_VALUE);
vbox.setLayoutX(200);
vbox.setLayoutY(300);


p.getChildren().addAll(bp,hb1,vbox);
cbscene=new Scene(sp,1402,1000);
 window.setScene(cbscene);
 window.setFullScreen(true);
	
}
Scene attview;
Label acname,lpresent,labsent;
HBox hacname,Hpresent,Habsent;
void attandenceview()
{
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	 HBox menubar=new HBox();
	
	menubar.setPrefHeight(45);
	menubar.setPrefWidth(1380);
	menubar.setSpacing(1100);
	menubar.setLayoutX(14);
	menubar.setLayoutY(214);
	menubar.setPadding(new Insets(5,5,5,5));
	menubar.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
	Button SIC=new Button("  SIC");
	SIC.setPrefWidth(100);
	SIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
	SIC.setAlignment(Pos.CENTER_LEFT);
	SIC.setOnAction(e->{
		window.setScene(homescene);
		window.setFullScreen(true);
	});
	fade(SIC);
	fademenu(mb);
	menubar.getChildren().addAll(SIC,mb);
	
	AnchorPane p=new AnchorPane();
	
	VBox setviewattandence=new VBox();
	setviewattandence.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: black;-fx-background-color: gray;");
	Label att=new Label("ATTENDANCE");
	att.setTextFill(Color.GRAY);
	att.setStyle("-fx-text-fill: gray; -fx-font-weight:Bold; -fx-font-size: 30px;");
	Label course = new Label("\tCourse\t\t");
	course.setTextFill(Color.BLACK);
	course.setStyle("-fx-font-size: 20px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Label present = new Label("\t\tPresent\t");
	present.setTextFill(Color.BLACK);
	present.setStyle("-fx-font-size: 20px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	Label absent = new Label("\t\t\tAbsent\t");
	absent.setTextFill(Color.BLACK);
	absent.setStyle("-fx-font-size: 20px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	HBox cpa = new HBox();
	setviewattandence.getChildren().add(att);
	cpa.setPadding(new Insets(5, 5, 5, 5));
	cpa.setPrefWidth(250);
	cpa.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
	cpa.getChildren().addAll(course, present, absent);
	setviewattandence.getChildren().add(cpa);
	
	if(studentlist.get(index).courses.size()<0 || studentlist.get(index).courses.size()==0 )
	{
		Alert a=new Alert(AlertType.ERROR);
		a.setContentText("No courses registered yet.");
		a.show();
		
	}
	else
	{
	for(int x=0;x<studentlist.get(index).courses.size();x++) {

		studentlist.get(index).courses.get(x).acname=new Label(studentlist.get(index).courses.get(x).getName());
		studentlist.get(index).courses.get(x).acname.setTextFill(Color.BLACK);
		studentlist.get(index).courses.get(x).acname.setFont(Font.font(20));
		studentlist.get(index).courses.get(x).lpresent=new Label(Integer.toString(studentlist.get(index).courses.get(x).present));
		studentlist.get(index).courses.get(x).lpresent.setTextFill(Color.BLACK);
		studentlist.get(index).courses.get(x).lpresent.setFont(Font.font(15));
		studentlist.get(index).courses.get(x).labsent=new Label(Integer.toString(studentlist.get(index).courses.get(x).absent));
		studentlist.get(index).courses.get(x).labsent.setTextFill(Color.BLACK);
		studentlist.get(index).courses.get(x).labsent.setFont(Font.font(15));
		studentlist.get(index).courses.get(x).hacname=new HBox();
		studentlist.get(index).courses.get(x).hacname.setPadding(new Insets(5,5,5,5));
		studentlist.get(index).courses.get(x).hacname.setPrefWidth(300);
		studentlist.get(index).courses.get(x).hacname.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		studentlist.get(index).courses.get(x).hacname.getChildren().add(studentlist.get(index).courses.get(x).acname);
		studentlist.get(index).courses.get(x).Hpresent=new HBox();
		studentlist.get(index).courses.get(x).Hpresent.setPadding(new Insets(5,5,5,5));
		studentlist.get(index).courses.get(x).Hpresent.setPrefWidth(200);
		studentlist.get(index).courses.get(x).Hpresent.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		studentlist.get(index).courses.get(x).Habsent=new HBox();
		studentlist.get(index).courses.get(x).Habsent.setPadding(new Insets(5,5,5,5));
		studentlist.get(index).courses.get(x).Habsent.setPrefWidth(250);
		studentlist.get(index).courses.get(x).Habsent.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");	
		studentlist.get(index).courses.get(x).Hpresent.getChildren().add(studentlist.get(index).courses.get(x).lpresent);
		studentlist.get(index).courses.get(x).Habsent.getChildren().add(studentlist.get(index).courses.get(x).labsent);
		studentlist.get(index).courses.get(x).AHBOX=new HBox(1);
		studentlist.get(index).courses.get(x).AHBOX.getChildren().addAll(studentlist.get(index).courses.get(x).hacname,studentlist.get(index).courses.get(x).Hpresent,studentlist.get(index).courses.get(x).Habsent);
	 setviewattandence.getChildren().addAll(studentlist.get(index).courses.get(x).AHBOX);

	}
	}
	
	
	ScrollPane sp=new ScrollPane(p);
	
	sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
	sp.setPrefHeight(1000);
	setviewattandence.setStyle("-fx-border-width: 2px; -fx-border-color: black");
	setviewattandence.setPadding(new Insets(5,5,5,5));
	setviewattandence.setPrefHeight(Control.USE_COMPUTED_SIZE);
	setviewattandence.setMaxHeight(Double.MAX_VALUE);
	setviewattandence.setLayoutX(300);
	setviewattandence.setLayoutY(430);
	p.getChildren().addAll(bp,menubar,setviewattandence);
	attview=new Scene(sp,1400,900);
	window.setScene(attview);
}

Scene Resultview;
Label Lrvname,Lrvmid,Lrvsessional,Lrvfinal,Lrvtotal,Lrvgrade,Lrvpoints;
HBox Hrvname,Hrvmid,Hrvsessional,Hrvfinal,Hrvtotal,Hrvgrade,Hrvpoints,Hcomplete1,Hall;
void resultView()
{
	 HBox menubar=new HBox();

		Image image=new Image("images//My Post.png");
		ImageView iv=new ImageView(image);
		bp.setTop(iv);
		menubar.setPrefHeight(45);
		menubar.setPrefWidth(1380);
		menubar.setSpacing(1100);
		menubar.setLayoutX(14);
		menubar.setLayoutY(214);
		menubar.setPadding(new Insets(5,5,5,5));
		menubar.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
		Button SIC=new Button("  SIC");
		SIC.setPrefWidth(100);
		SIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
		SIC.setAlignment(Pos.CENTER_LEFT);
		SIC.setOnAction(e->{
			window.setScene(homescene);
			window.setFullScreen(true);
		});
		fade(SIC);
		fademenu(mb);
		menubar.getChildren().addAll(SIC,mb);
		
		AnchorPane p=new AnchorPane();
		//HEADER
		
		Lrvname=new Label("COURSE NAME");
		Lrvmid=new Label("MID");
		Lrvsessional = new Label("SESSIONAL");
		Lrvfinal=new Label("FINAL");
		Lrvtotal=new Label("TOTAL");
		Lrvgrade=new Label("GRADE");
		Lrvpoints=new Label("POINTS");
		//Label Colors
		Lrvname.setTextFill(Color.WHITESMOKE);
		Lrvmid.setTextFill(Color.WHITESMOKE);
		Lrvsessional.setTextFill(Color.WHITESMOKE);
		Lrvfinal.setTextFill(Color.WHITESMOKE);
		Lrvtotal.setTextFill(Color.WHITESMOKE);
		Lrvgrade.setTextFill(Color.WHITESMOKE);
		Lrvpoints.setTextFill(Color.WHITESMOKE);
		//Label fonts
		Lrvname.setFont(Font.font("Arial",21));
		Lrvmid.setFont(Font.font("Arial",21));
		Lrvsessional.setFont(Font.font("Arial",21));
		Lrvfinal.setFont(Font.font("Arial",21));
		Lrvtotal.setFont(Font.font("Arial",21));
		Lrvgrade.setFont(Font.font("Arial",21));
		Lrvpoints.setFont(Font.font("Arial",21));
		// Label's HBox
		Hrvname=new HBox();
		Hrvmid=new HBox();
		Hrvsessional = new HBox();
		Hrvfinal=new HBox();
		Hrvtotal=new HBox();
		Hrvgrade=new HBox();
		Hrvpoints=new HBox();
		Hcomplete1=new HBox();
		Hall=new HBox();
		// Label's HBOX ....
		//
		Hrvname.setPadding(new Insets(5,5,5,5));
		Hrvname.setPrefWidth(400);
		Hrvname.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvname.getChildren().add(Lrvname);
		
		Hrvmid.setPadding(new Insets(5,5,5,5));
		Hrvmid.setPrefWidth(100);
		Hrvmid.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvmid.getChildren().add(Lrvmid);
		
		Hrvsessional.setPadding(new Insets(5,5,5,5));
		Hrvsessional.setPrefWidth(100);
		Hrvsessional.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvsessional.getChildren().add(Lrvsessional);
		
		Hrvfinal.setPadding(new Insets(5,5,5,5));
		Hrvfinal.setPrefWidth(100);
		Hrvfinal.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvfinal.getChildren().add(Lrvfinal);
		
		Hrvtotal.setPadding(new Insets(5,5,5,5));
		Hrvtotal.setPrefWidth(100);
		Hrvtotal.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvtotal.getChildren().add(Lrvtotal);
		
		Hrvgrade.setPadding(new Insets(5,5,5,5));
		Hrvgrade.setPrefWidth(100);
		Hrvgrade.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvgrade.getChildren().add(Lrvgrade);
		
		Hrvpoints.setPadding(new Insets(5,5,5,5));
		Hrvpoints.setPrefWidth(100);
		Hrvpoints.setStyle("-fx-font-width: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hrvpoints.getChildren().add(Lrvpoints);
		Hcomplete1=new HBox();
		Hcomplete1.getChildren().addAll(Hrvname,Hrvmid,Hrvsessional,Hrvfinal,Hrvtotal,Hrvgrade,Hrvpoints);
		//
		VBox viewResult=new VBox();
		viewResult.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: black;-fx-background-color: gray;");
		Label ER=new Label("EXAM RESULT");
		ER.setTextFill(Color.GRAY);
		ER.setStyle("-fx-text-fill: gray; -fx-font-weight:Bold; -fx-font-size: 40px;");
		viewResult.getChildren().addAll(ER,Hcomplete1);
		
		if(studentlist.get(index).courses.size()<0 || studentlist.get(index).courses.size()==0 )
		{
			Alert a=new Alert(AlertType.ERROR);
			a.show();
			
		}
		else
		{
		for(int x=0;x<studentlist.get(index).courses.size();x++) {
//Label
			Lrvname=new Label(studentlist.get(index).courses.get(x).getName());
			Lrvmid=new Label(Integer.toString(studentlist.get(index).courses.get(x).Mid));
			Lrvsessional=new Label(Integer.toString(studentlist.get(index).courses.get(x).Sessional));
			Lrvfinal=new Label(Integer.toString(studentlist.get(index).courses.get(x).Final));
			Lrvtotal=new Label(Integer.toString(studentlist.get(index).courses.get(x).Total));
			Lrvgrade=new Label(studentlist.get(index).courses.get(x).getGrade());
			Lrvpoints=new Label(Double.toString((studentlist.get(index).courses.get(x).points)));
			//Label Colors
			Lrvname.setTextFill(Color.BLACK);
			Lrvmid.setTextFill(Color.BLACK);
			Lrvsessional.setTextFill(Color.BLACK);
			Lrvfinal.setTextFill(Color.BLACK);
			Lrvtotal.setTextFill(Color.BLACK);
			Lrvgrade.setTextFill(Color.BLACK);
			Lrvpoints.setTextFill(Color.BLACK);
			//Label fonts
			Lrvname.setFont(Font.font("Calibri",15));
			Lrvmid.setFont(Font.font("Calibri",15));
			Lrvsessional.setFont(Font.font("Calibri",15));
			Lrvfinal.setFont(Font.font("Calibri",15));
			Lrvtotal.setFont(Font.font("Calibri",15));
			Lrvgrade.setFont(Font.font("Calibri",15));
			Lrvpoints.setFont(Font.font("Calibri",15));
			// Label's HBox
			Hrvname=new HBox();
			Hrvmid=new HBox();
			Hrvsessional=new HBox();
			Hrvfinal=new HBox();
			Hrvtotal=new HBox();
			Hrvgrade=new HBox();
			Hrvpoints=new HBox();
			Hcomplete1=new HBox();
			Hall=new HBox();
			// Label's HBOX ....
			//
			Hrvname.setPadding(new Insets(5,5,5,5));
			Hrvname.setPrefWidth(400);
			Hrvname.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvname.getChildren().add(Lrvname);
			
			Hrvmid.setPadding(new Insets(5,5,5,5));
			Hrvmid.setPrefWidth(100);
			Hrvmid.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvmid.getChildren().add(Lrvmid);
			
			Hrvsessional.setPadding(new Insets(5,5,5,5));
			Hrvsessional.setPrefWidth(100);
			Hrvsessional.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvsessional.getChildren().add(Lrvsessional);
			
			Hrvfinal.setPadding(new Insets(5,5,5,5));
			Hrvfinal.setPrefWidth(100);
			Hrvfinal.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvfinal.getChildren().add(Lrvfinal);
			
			Hrvtotal.setPadding(new Insets(5,5,5,5));
			Hrvtotal.setPrefWidth(100);
			Hrvtotal.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvtotal.getChildren().add(Lrvtotal);
			
			Hrvgrade.setPadding(new Insets(5,5,5,5));
			Hrvgrade.setPrefWidth(100);
			Hrvgrade.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvgrade.getChildren().add(Lrvgrade);
			
			Hrvpoints.setPadding(new Insets(5,5,5,5));
			Hrvpoints.setPrefWidth(100);
			Hrvpoints.setStyle("-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			Hrvpoints.getChildren().add(Lrvpoints);
			Hcomplete1=new HBox();
			Hcomplete1.getChildren().addAll(Hrvname,Hrvmid,Hrvsessional,Hrvfinal,Hrvtotal,Hrvgrade,Hrvpoints);
			viewResult.getChildren().addAll(Hcomplete1);

		}
		}
		
		
		ScrollPane sp=new ScrollPane(p);
		
		sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
		sp.setPrefHeight(1000);
		viewResult.setStyle("-fx-border-width: 2px; -fx-border-color: black");
		viewResult.setPadding(new Insets(5,5,5,5));
		viewResult.setPrefHeight(Control.USE_COMPUTED_SIZE);
		viewResult.setMaxHeight(Double.MAX_VALUE);
		viewResult.setLayoutX(300);
		viewResult.setLayoutY(430);
		Label CGPA=new Label(Double.toString(cgpa/cdh));
		viewResult.getChildren().add(CGPA);
		p.getChildren().addAll(bp,menubar,viewResult);
		Resultview=new Scene(sp,1400,900);
		window.setScene(Resultview);
		window.setFullScreen(true);
}
// TEacher update result:: Hanzalah//	
Scene resultUpdatescene;int cdh=0;double cgpa=0.0;
void updateResult()
{
	Image image=new Image("images//My Post.png");
	ImageView iv=new ImageView(image);
	bp.setTop(iv);
	 HBox menubar=new HBox();
		menubar.setPrefHeight(45);
		menubar.setPrefWidth(1380);
		menubar.setSpacing(990);
		menubar.setLayoutX(14);
		menubar.setLayoutY(214);
		menubar.setPadding(new Insets(5,5,5,5));
		menubar.setStyle("-fx-background-color: lightslategray; -fx-border-width: 2px;-fx-border-color: #FFFFFF;");
		Button FIC=new Button("  FIC");
		FIC.setPrefWidth(100);
		FIC.setStyle("-fx-background-color : lightslategray;-fx-text-fill: #FFFFFF;-fx-font-size: 25px;-fx-font-weight: Bold");
		FIC.setAlignment(Pos.CENTER_LEFT);
		FIC.setOnAction(e->{
			window.setScene(teacherhomescene);
			window.setFullScreen(true);
		});
		fade(FIC);
		fademenu(mb);
		menubar.getChildren().addAll(FIC,mb);
		
	
		AnchorPane p=new AnchorPane();
		VBox UpdateExamResult=new VBox();
		HBox txt,txt2,txt3;

		for(int x=0;x<studentlist.size();x++)
		{
			for(int y=0;y<studentlist.get(x).courses.size();y++)
			{
		if(Teacherlist.get(tindex).getCourse().equalsIgnoreCase(studentlist.get(x).courses.get(y).getName()))
		{
		
			
			attname=new Label(studentlist.get(x).getName());
			acnamebox=new HBox();
			acnamebox.getChildren().add(attname);
			acnamebox.setPadding(new Insets(5,5,5,5));
			acnamebox.setPrefWidth(300);
			acnamebox.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			txt=new HBox();
			txt.setPadding(new Insets(5,5,5,5));
			txt.setPrefWidth(200);
			txt.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			TextField t=new TextField();
			t.setPromptText("MID");
			Teacherlist.get(x).tbarrayMid.add(t);
			txt.getChildren().add(Teacherlist.get(x).tbarrayMid.get(y));
			
			txt2=new HBox();
			txt2.setPadding(new Insets(5,5,5,5));
			txt2.setPrefWidth(200);
			txt2.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
			TextField t2=new TextField();
			t2.setPromptText("FINAL");
			Teacherlist.get(x).tbarrayFinal.add(t2);
			txt2.getChildren().add(Teacherlist.get(x).tbarrayFinal.get(y));
			
			TextField t3=new TextField();
			t3.setPromptText("SESSIONAL");
			Teacherlist.get(x).tbarraySessional.add(t3);
			txt.getChildren().add(Teacherlist.get(x).tbarraySessional.get(y));
			txt3=new HBox();
			txt3.setPadding(new Insets(5,5,5,5));
			txt3.setPrefWidth(200);
			txt3.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");

			atthbox=new HBox();
			atthbox.getChildren().addAll(acnamebox,txt,txt2,txt3);
			UpdateExamResult.getChildren().add(atthbox);
	
		}
			}
			
	}
		
		
		ScrollPane sp=new ScrollPane(p);
		sp.setVbarPolicy(ScrollBarPolicy.ALWAYS);
		sp.setPrefHeight(1000);
		UpdateExamResult.setStyle("-fx-border-width: 2px; -fx-border-color: black");
		UpdateExamResult.setPadding(new Insets(5,5,5,5));
		UpdateExamResult.setPrefHeight(Control.USE_COMPUTED_SIZE);
		UpdateExamResult.setMaxHeight(Double.MAX_VALUE);
		UpdateExamResult.setLayoutX(300);
		UpdateExamResult.setLayoutY(430);
		UpdateExamResult.setLayoutX(300);
		UpdateExamResult.setLayoutY(430);
		 
	Button UPDATE=new Button("UPDATE");
	UPDATE.setOnAction(e->{
		
		for(int x=0;x<studentlist.size();x++)
		{
			for(int y=0;y<studentlist.get(x).courses.size();y++)
			{
				
		if(Teacherlist.get(tindex).getCourse().equalsIgnoreCase(studentlist.get(x).courses.get(y).getName()))
		{
			
			if(Teacherlist.get(x).tbarrayMid.get(y).getText().isEmpty()!=true &&Teacherlist.get(x).tbarraySessional.get(y).getText().isEmpty()!=true && Teacherlist.get(x).tbarrayFinal.get(y).getText().isEmpty()!=true)
			{
				studentlist.get(x).courses.get(y).Final=Integer.parseInt(Teacherlist.get(x).tbarrayFinal.get(y).getText());
				studentlist.get(x).courses.get(y).Sessional=Integer.parseInt(Teacherlist.get(x).tbarraySessional.get(y).getText());
				studentlist.get(x).courses.get(y).Mid=Integer.parseInt(Teacherlist.get(x).tbarrayMid.get(y).getText());
				studentlist.get(x).courses.get(y).setGrade(cGrade(studentlist.get(x).courses.get(y).Final+ studentlist.get(x).courses.get(y).Sessional  + studentlist.get(x).courses.get(y).Mid));
				studentlist.get(x).courses.get(y).Total=studentlist.get(x).courses.get(y).Final + studentlist.get(x).courses.get(y).Sessional + studentlist.get(x).courses.get(y).Mid;
				studentlist.get(x).courses.get(y).points=cGPA(studentlist.get(x).courses.get(y).Final+ studentlist.get(x).courses.get(y).Sessional + studentlist.get(x).courses.get(y).Mid);
				 cdh+=studentlist.get(x).courses.get(y).credithour;
				cgpa+=studentlist.get(x).courses.get(y).points*studentlist.get(x).courses.get(y).getCredithour();
				
			}
			else
			{
				Alert a= new Alert(AlertType.ERROR);
				a.setContentText("FILL ALL FIELDS");
				a.show();
				break;
			
			}
		
		}
		}
	}
			
		
	});
	
	UpdateExamResult.getChildren().add(UPDATE);

		p.getChildren().addAll(bp,menubar,UpdateExamResult);
		resultUpdatescene=new Scene(sp,1400,900);
		window.setScene(resultUpdatescene);
		window.setFullScreen(true);
	}

String cGrade(int cTotal)
{
	
	if(cTotal<60)
	{
		return "F";
	}
	else if(cTotal>=60 && cTotal<68)
	{
		return "C";
	}
	else if(cTotal>=68 && cTotal<74)
	{
		return "C+";
	}
	else if(cTotal>=74 && cTotal<81)
	{
		return "B";
	}
	else if(cTotal>=81 && cTotal<88)
	{
		return "B+";
	}
	else if(cTotal>=88 && cTotal<101)
	{
		return "A";
	}
	else
	{
	return "NULL";
	}
}
double cGPA(int cTotal )
{
	if(cTotal<60)
	{
		return 0.0;
	}
	else if(cTotal>=60 && cTotal<68)
	{
		return  2.0;
	}
	else if(cTotal>=68 && cTotal<74)
	{
		return 2.5;
	}
	else if(cTotal>=74 && cTotal<81)
	{
		return  3.0;
	}
	else if(cTotal>=81 && cTotal<88)
	{
		return 3.5;
	}
	else if(cTotal>=88 && cTotal<101)
	{
		return 4.0;
	}
	
	else {
	return 0.0;
	}
}
}




