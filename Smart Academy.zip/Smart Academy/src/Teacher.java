import java.util.ArrayList;

import javafx.scene.control.TextField;

public class Teacher extends Person
{
	String Course;
public	ArrayList<TextField> tbarrayMid=new ArrayList();
public	ArrayList<TextField> tbarrayFinal=new ArrayList();
public	ArrayList<TextField> tbarraySessional=new ArrayList();

public Teacher(String name, String email, String password, String gender, String birthday, String phonenumber,String campus, String department,String type) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.gender = gender;
		this.birthday = birthday;
		this.phonenumber = phonenumber;
		this.campus = campus;
		this.department = department;
		this.type=type;
		
	}
	
	Teacher()
	{
		this.name="";
		this.email="";
		this.password="";
		this.gender="";
		this.birthday="";
		this.phonenumber ="";
		this.campus = "EDC TOWER";
		this.department = "";
		this.Course="";
	}

	public String getCourse() {
		return Course;
	}

	public void setCourse(String course) {
		Course = course;
	}
	
}