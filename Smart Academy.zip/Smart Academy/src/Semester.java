
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Semester extends Course
{
	
	
	 
	ObservableList<VBox> vblist;
	
Semester()
{
	vblist=FXCollections.observableArrayList();
}
void semester(ObservableList<Course> semester1, String name)
{
	
	VBox v=new VBox();
	 Course sc=new Course();
	Label namee=new Label();
	HBox label=new HBox();
	label.setPrefSize(1300, 20);
	label.setStyle("-fx-background-color: black;-fx-text-fill :white;-fx-font-weight: Bold;");
	namee.setText(name);
	namee.setFont(Font.font("calibri", 30));
	namee.setTextFill(Color.WHITE);
	label.getChildren().add(namee);
	v.getChildren().addAll(label,sc.head());
	
	 for(int x=0;x <semester1.size();x++)
	 {
		
		 sc =semester1.get(x);
		 v.getChildren().add(sc.setcourse());
		 vblist.add(v);
		 
	 }
	
	 
}


	
	 
}
 
