
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Course
{
	protected String name,grade,teacher,PreRequisite,code,Timetable;
	double points,CGPA;
	 public int present,absent,credithour,Mid,Sessional,Final,Total;
	Label acname,lpresent,labsent;
	HBox hacname,Hpresent,Habsent,AHBOX;
	CheckBox markatt;
	CheckBox checkb=new CheckBox();
	HBox Hcode=new HBox();
	Label Lcode=new Label("Code");
	HBox HPreRequisite=new HBox();
	Label lPreRequisite=new Label("PreReq");
	
	HBox Hcredithour=new HBox();
	Label Lcredithour=new Label("CrdHrs");
	
	HBox HCourseName=new HBox();
	Label LCourseName=new Label("Course Name");
	
	HBox HGrade=new HBox();
	Label LGrade=new Label("Grade");
	
	HBox Hteacher=new HBox();
	Label Lteacher=new Label("Teacher");
	
	HBox HTimetable=new HBox();
	Label LTimetable=new Label("Time Table");
	
	
	
	
	public Course(String name, String grade, String teacher, String preRequisite, String code, String timetable,int credithour) {
		
		super();
		this.name = name;
		this.grade = grade;
		this.teacher = teacher;
		PreRequisite = preRequisite;
		this.code = code;
		Timetable = timetable;
		this.credithour = credithour;
		markatt=new CheckBox();
		present=0;
		absent=0;
		points=0.0;
		Mid=0;Sessional = 0; Final=0;Total=0;CGPA=0.0;
	}
	
	public Course()
	{
		this.name = "";
		this.grade = "";
		this.teacher = "";
		this.PreRequisite = "";
		this.code = "";
		this.Timetable = "";
		this.credithour = 0;
		present=0;
		absent=0;
		markatt=new CheckBox();
		Mid=0;Sessional = 0; Final=0;Total=0;
		CGPA=0.0;
	}
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getPreRequisite() {
		return PreRequisite;
	}
	public void setPreRequisite(String preRequisite) {
		PreRequisite = preRequisite;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTimetable() {
		return Timetable;
	}
	public void setTimetable(String timetable) {
		Timetable = timetable;
	}
	public int getCredithour() {
		return credithour;
	}
	public void setCredithour(int credithour) {
		this.credithour = credithour;
	}
	
	public int getPresent() {
		return present;
	}
	public void setPresent(int present) {
		this.present = present;
	}
	public int getAbsent() {
		return absent;
	}
	public void setAbsent(int absent) {
		this.absent = absent;
	}
	
	  HBox head()
	{
		  HBox ch=new HBox();
		  Lcode.setTextFill(Color.WHITE);
		  Lcode.setAlignment(Pos.CENTER);
		  lPreRequisite.setTextFill(Color.WHITE);
		  Lcredithour.setTextFill(Color.WHITE);
		  LCourseName.setTextFill(Color.WHITE);
		  LCourseName.setAlignment(Pos.CENTER);
		  LGrade.setTextFill(Color.WHITE);
		  Lteacher.setTextFill(Color.WHITE);
		  LTimetable.setTextFill(Color.WHITE);
		  //
		  
		  Lcode.setFont(Font.font(16));
		  lPreRequisite.setFont(Font.font(16));
		  Lcredithour.setFont(Font.font(16));
		  LCourseName.setFont(Font.font(16));
		  LGrade.setFont(Font.font(16));
		  Lteacher.setFont(Font.font(16));
		  LTimetable.setFont(Font.font(16));
		  
		  
		  
		  HBox Hheader=new HBox();
		  Hcode.getChildren().add(Lcode);
		  Hcode.setPadding(new Insets(5,5,5,5));
		  Hcode.setPrefWidth(150);
		  Hcode.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HPreRequisite.getChildren().addAll(lPreRequisite);
		HPreRequisite.setPadding(new Insets(5,5,5,5));
		HPreRequisite.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HPreRequisite.setPrefWidth(100);
		Hcredithour.getChildren().addAll(Lcredithour);
		Hcredithour.setPadding(new Insets(5,5,5,5));
		Hcredithour.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hcredithour.setPrefWidth(70);
		HCourseName.getChildren().addAll(LCourseName);
		HCourseName.setPadding(new Insets(5,5,5,5));
		HCourseName.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HCourseName.setPrefWidth(380);
		HGrade.getChildren().addAll(LGrade);
		HGrade.setPadding(new Insets(5,5,5,5));
		HGrade.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HGrade.setPrefWidth(100);
		Hteacher.getChildren().addAll(Lteacher);
		Hteacher.setPadding(new Insets(5,5,5,5));
		Hteacher.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		Hteacher.setPrefWidth(200);
		HTimetable.getChildren().addAll(LTimetable);
		HTimetable.setPadding(new Insets(5,5,5,5));
		HTimetable.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HTimetable.setPrefWidth(200);
		ch.setPadding(new Insets(5,5,5,5));
		ch.setStyle("-fx-font-size: 13px; -fx-text-fill:gray;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		ch.setPrefWidth(100);
		Hheader.getChildren().addAll(ch,Hcode,HPreRequisite,Hcredithour,HCourseName,HGrade,Hteacher,HTimetable);
		Hheader.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: black;-fx-background-color: gray;");
		return Hheader;
		
	}
	protected HBox setcourse ()
	{
		
		Label cd=new Label(this.code);
		Label pre=new Label(this.PreRequisite); 
		Label crd=new Label(Integer.toString(this.credithour) );  
		Label cn=new Label(this.name);
		Label grd=new Label(this.grade);
		Label teach=new Label(this.teacher);
		Label Tt=new Label(this.Timetable);
		//
		cd.setTextFill(Color.BLACK);
		pre.setTextFill(Color.BLACK);
		crd.setTextFill(Color.BLACK);
		cn.setTextFill(Color.BLACK);
		grd.setTextFill(Color.BLACK);
		teach.setTextFill(Color.BLACK);
		Tt.setTextFill(Color.BLACK);

		//
		cd.setFont(Font.font(15));
		pre.setFont(Font.font(15));
		crd.setFont(Font.font(15));
		cn.setFont(Font.font(15));
		grd.setFont(Font.font(15));
		teach.setFont(Font.font(15));
		Tt.setFont(Font.font(15));
		
		//
		HBox check=new HBox();
		
		check.setPrefWidth(100);
		check.getChildren().add(checkb);
		check.setPadding(new Insets(5,5,5,5));
		check.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px; -fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h1=new HBox();
		h1.getChildren().add(cd);
		h1.setPadding(new Insets(5,5,5,5));
		h1.setPrefWidth(150);
		h1.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h2=new HBox();
		h2.getChildren().add(pre);
		h2.setPadding(new Insets(5,5,5,5));
		h2.setPrefWidth(100);
		h2.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h3=new HBox();
		h3.getChildren().add(crd);
		h3.setPadding(new Insets(5,5,5,5));
		h3.setPrefWidth(70);
		h3.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h4=new HBox();
		h4.getChildren().add(cn);
		h4.setPadding(new Insets(5,5,5,5));
		h4.setPrefWidth(380);
		h4.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h5=new HBox();
		h5.getChildren().add(grd);
		h5.setPadding(new Insets(5,5,5,5));
		h5.setPrefWidth(100);
		h5.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h6=new HBox();
		h6.getChildren().add(teach);
		h6.setPadding(new Insets(5,5,5,5));
		h6.setPrefWidth(200);
		h6.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		HBox h7=new HBox();
		h7.getChildren().add(Tt);
		h7.setPadding(new Insets(5,5,5,5));
		h7.setPrefWidth(200);
		h7.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: whitesmoke;-fx-background-color: gray;");
		
		HBox hb=new HBox();
		hb.setStyle("-fx-font-size: 13px;-fx-font-weight: Bold;-fx-border-width: 1px;-fx-border-color: black;-fx-background-color: gray;");
		hb.getChildren().addAll(check,h1,h2,h3,h4,h5,h6,h7);
		
		
		return hb;
	}
}